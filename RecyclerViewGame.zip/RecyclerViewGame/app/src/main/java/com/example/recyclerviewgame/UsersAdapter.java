package com.example.recyclerviewgame;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recyclerviewgame.R;
import com.example.recyclerviewgame.UserModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

public class UsersAdapter extends RecyclerView.Adapter<UsersAdapter.ViewHolder> {

    // creating a variable for array list and context.
    private ArrayList<UserModel> courseModelArrayList;

    // creating a constructor for our variables.
    public UsersAdapter(ArrayList<UserModel> courseModelArrayList, Context context) {
        this.courseModelArrayList = courseModelArrayList;
    }


    // method for filtering our recyclerview items.
    public void filterList(ArrayList<UserModel> filterlist) {
        // below line is to add our filtered
        // list in our course array list.
        courseModelArrayList = filterlist;
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public UsersAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // below line is to inflate our layout.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_users, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UsersAdapter.ViewHolder holder, int position) {
        // setting data to our views of recycler view.
        UserModel model = courseModelArrayList.get(position);
        holder.courseNameTV.setText(model.getgameName());
        holder.courseDescTV.setText(model.getgameDescription());
    }

    @Override
    public int getItemCount() {
        // returning the size of array list.
        return courseModelArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        // creating variables for our views.
        private final TextView courseNameTV;
        private final TextView courseDescTV;
        private final AppCompatButton button1;
        private final FloatingActionButton button2;
        RelativeLayout coordinatorLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing our views with their ids.
            courseNameTV = itemView.findViewById(R.id.idTVCourseName);
            courseDescTV = itemView.findViewById(R.id.idTVCourseDescription);
            button1 = itemView.findViewById(R.id.button_id_Login);
            button2 = itemView.findViewById(R.id.floatingActionButton);

            coordinatorLayout = itemView.findViewById(R.id.coordinatorLayout);

            button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (button1.getText().equals("Buy")) {
                        Snackbar snackbar = Snackbar
                                .make(coordinatorLayout, "Game Added to Cart", Snackbar.ANIMATION_MODE_SLIDE);
                        snackbar.show();
                        button1.setBackgroundColor(Color.GREEN);
                        button1.setText("Added");
                        button1.setTextColor(Color.BLACK);
                    } else if  (button1.getText().equals("Added")){
                        Snackbar snackbar = Snackbar
                                .make(coordinatorLayout, "Game Removed from Cart", Snackbar.ANIMATION_MODE_SLIDE);
                        snackbar.show();
                        button1.setText("Buy");
                        button1.setBackgroundColor(Color.GRAY);
                    }
                }
            });
            button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String txt = "The following game prices are: " +courseDescTV.getText().toString();
                    Snackbar snackbar = Snackbar
                            .make(coordinatorLayout,txt , Snackbar.ANIMATION_MODE_SLIDE);
                    snackbar.show();

                }
            });
        }
    }
}