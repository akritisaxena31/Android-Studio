package com.example.recyclerviewgame;

import java.io.Serializable;


public class UserModel {
    // variables for our course
    // name and description.
    private String gameName;
    private String gameDescription;

    // creating constructor for our variables.
    public UserModel(String gameName, String gameDescription) {
        this.gameName = gameName;
        this.gameDescription = gameDescription;
    }

    // creating getter and setter methods.
    public String getgameName() {
        return gameName;
    }

    public void setgameName(String gameName) {
        this.gameName = gameName;
    }

    public String getgameDescription() {
        return gameDescription;
    }

    public void setgameDescription(String gameDescription) {
        this.gameDescription = gameDescription;
    }
}
