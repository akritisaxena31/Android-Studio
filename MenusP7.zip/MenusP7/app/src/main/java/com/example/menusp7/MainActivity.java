package com.example.menusp7;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ShareCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageButton button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (ImageButton) findViewById(R.id.imageButton);


        // Setting onClick behavior to the button
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Initializing the popup menu and giving the reference as current context
                PopupMenu popupMenu = new PopupMenu(MainActivity.this, button);

                // Inflating popup menu from popup_menu.xml file
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());
                if(popupMenu.getMenu() instanceof MenuBuilder){
                    MenuBuilder m1 = (MenuBuilder) popupMenu.getMenu();
                    //noinspection RestrictedApi
                    m1.setOptionalIconsVisible(true);
                }
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        // Toast message on menu item clicked
                        Toast.makeText(MainActivity.this, "You Clicked " + menuItem.getTitle(), Toast.LENGTH_SHORT).show();
                        switch (menuItem.getItemId()) {
                            case R.id.piccyber:
                                 shareText(view);
                                return true;
                            case R.id.infocyber:
                                Toast.makeText(MainActivity.this, "Cowardy Courage Version 1.5", Toast.LENGTH_SHORT).show();
                                return true;
                            case R.id.buy:
                                openWebsite(view);
                                return true;
                            default:
                                return true;
                        }
                    }
                });
                // Showing the popup menu
                popupMenu.show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        if(menu instanceof MenuBuilder){
            MenuBuilder m = (MenuBuilder) menu;
            //noinspection RestrictedApi
            m.setOptionalIconsVisible(true);
        }
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Toast.makeText(this, "Selected Item: " +item.getTitle(), Toast.LENGTH_SHORT).show();
        switch (item.getItemId()) {
            case R.id.search_item:
                String url = "https://www.cyberpunk.net/in/en/";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
                

                return true;
            case R.id.share_item:
                String mimeType = "text/plain";
                ShareCompat.IntentBuilder
                        .from(this)
                        .setType(mimeType)
                        .startChooser();

                return true;
            case R.id.bookmark_item:
                Toast.makeText(this, "Page Bookmarked", Toast.LENGTH_SHORT).show();
                return true;

                case R.id.call:
                Uri u = Uri.parse("tel:" + "97555213123");
                Intent ik = new Intent(Intent.ACTION_DIAL, u);

                try
                {
                    startActivity(ik);
                }
                catch (SecurityException s)
                {
                    Toast.makeText(this, "An error occurred", Toast.LENGTH_LONG).show();
                }
                    return true;

            case R.id.steam:
                String url2 = "https://steamdb.info/app/1091500/";
                Intent i3 = new Intent(Intent.ACTION_VIEW);
                i3.setData(Uri.parse(url2));
                startActivity(i3);
                return true;

            case R.id.email:
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("plain/text");
                intent.putExtra(Intent.EXTRA_EMAIL, new String[] { "aru.akriti@gmail.com" });
                intent.putExtra(Intent.EXTRA_SUBJECT, "Cowardy Courage Customer Support");
                intent.putExtra(Intent.EXTRA_TEXT, "Game Support Ticket");
                startActivity(Intent.createChooser(intent, ""));

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void callSecondActivity(View view){
        Intent i = new Intent(getApplicationContext(), SecondActivity.class);
        startActivity(i);
    }
    public void openWebsite(View view) {
        String url = "https://www.cyberpunk.net/in/en/";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }

    public void shareText(View view) {
        String mimeType = "text/plain";
        ShareCompat.IntentBuilder
                .from(this)
                .setType(mimeType)
                .startChooser();
    }


}