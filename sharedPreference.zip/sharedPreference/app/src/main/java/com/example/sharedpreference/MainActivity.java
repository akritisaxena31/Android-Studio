package com.example.sharedpreference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText first,last,age,email;
    RadioGroup sub;
    RadioButton science,comm,arts;
    Button save;
    SharedPreferences sharedPreferences;

    private static final String SHARED_PREF_NAME="mypref";
    private static final String KEY_FNAME="first name";
    private static final String KEY_LNAME="last name";
    private static final String KEY_EMAIL="email";
    private static final String KEY_AGE="age";
    private static final String KEY_SUBJECT="subject";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        first=findViewById(R.id.firstname);
        last=findViewById(R.id.lastname);
        age=findViewById(R.id.age);
        email=findViewById(R.id.email);
        sub=findViewById(R.id.radio);
        science=findViewById(R.id.science);
        comm=findViewById(R.id.commerce);
        arts=findViewById(R.id.arts);
        save=findViewById(R.id.button2);


        sharedPreferences=getSharedPreferences(SHARED_PREF_NAME,MODE_PRIVATE);


        String name=sharedPreferences.getString(KEY_FNAME,null);
        if(name!=null){
            Intent intent=new Intent(MainActivity.this,HomeActivity.class);
            startActivity(intent);
        }

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.putString(KEY_FNAME,first.getText().toString());
                editor.putString(KEY_LNAME,last.getText().toString());
                editor.putString(KEY_EMAIL,email.getText().toString());
                editor.putString(KEY_AGE,age.getText().toString());
                if(science.isChecked()){
                    editor.putString(KEY_SUBJECT,"School of Sciences");
                }
                else if (comm.isChecked()){
                    editor.putString(KEY_SUBJECT,"School of Business");
                }
                else if(arts.isChecked()){
                    editor.putString(KEY_SUBJECT,"School of Arts");
                }
                editor.apply();
                Intent intent=new Intent(MainActivity.this,HomeActivity.class);
                startActivity(intent);

                Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_SHORT).show();


            }
        });
    }


}