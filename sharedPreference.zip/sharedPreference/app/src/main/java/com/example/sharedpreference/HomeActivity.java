package com.example.sharedpreference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {
    TextView name,email,age,sub;
    Button logout;
    SharedPreferences sharedPreferences;

    private static final String SHARED_PREF_NAME="mypref";
    private static final String KEY_FNAME="first name";
    private static final String KEY_LNAME="last name";
    private static final String KEY_EMAIL="email";
    private static final String KEY_AGE="age";
    private static final String KEY_SUBJECT="subject";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        name=findViewById(R.id.name);
        email=findViewById(R.id.mail);
        age=findViewById(R.id.age1);
        sub=findViewById(R.id.sub);
        logout=findViewById(R.id.logout);

        sharedPreferences=getSharedPreferences(SHARED_PREF_NAME,MODE_PRIVATE);

        String fname=sharedPreferences.getString(KEY_FNAME,null);
        String lname=sharedPreferences.getString(KEY_LNAME,null);
        String mail=sharedPreferences.getString(KEY_EMAIL,null);
        String age1=sharedPreferences.getString(KEY_AGE,null);
        String subject=sharedPreferences.getString(KEY_SUBJECT,null);
         if(fname!=null||lname!=null||mail!=null||subject!=null||age1!=null){
             name.setText("Full name: "+fname+" "+lname);
             email.setText("Email ID: "+mail);
             age.setText("Age: "+age1);
             sub.setText("Subject: "+subject);
         }

         logout.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 SharedPreferences.Editor editor=sharedPreferences.edit();
                 editor.clear();
                 editor.commit();
                 Toast.makeText(HomeActivity.this, "Logged out Successfully", Toast.LENGTH_SHORT).show();
                 finish();
             }
         });
    }
}